$(document).ready(function() {
	$('.parallax__list>li').addClass('layer');
	$('.parallax__list').parallax();
	$('.wrapper').addClass('active');
});